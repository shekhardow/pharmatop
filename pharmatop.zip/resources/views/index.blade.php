<div style="display: flex; align-items: center; justify-content: center;">
    <h1>Welcome</h1>
</div>
