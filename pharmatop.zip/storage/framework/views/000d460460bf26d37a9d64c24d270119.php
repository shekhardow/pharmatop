<div style="display: flex; align-items: center; justify-content: center;">
    <h1>Welcome</h1>
</div>
<?php /**PATH C:\xampp\htdocs\pharmatop\resources\views\index.blade.php ENDPATH**/ ?>